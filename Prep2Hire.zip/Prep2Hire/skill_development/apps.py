from django.apps import AppConfig


class SkillDevelopmentConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'skill_development'
