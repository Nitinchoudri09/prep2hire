# admin.py
from django.contrib import admin
from .models import Question, Option, CareerSuggestion
admin.site.register(Question)
admin.site.register(Option)
admin.site.register(CareerSuggestion)
